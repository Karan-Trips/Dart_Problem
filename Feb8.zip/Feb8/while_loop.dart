void main() {
  int i = 1;
  do {
    print("Number $i");
    i++;
  } while (i <= 10);
}
